using System.Reflection;
//[assembly: AssemblyFileVersion("2013.11.*")]
[assembly: AssemblyVersion("2013.11")]
//[assembly: log4net.Config.XmlConfigurator(Watch=false)]
